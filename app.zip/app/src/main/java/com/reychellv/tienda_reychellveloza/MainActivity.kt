package com.reychellv.tienda_reychellveloza

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val codigo = findViewById<EditText>(R.id.editTextCodigo)
        val nombre = findViewById<EditText>(R.id.editTextNombreProducto)
        val precio = findViewById<EditText>(R.id.editTextNumberPrecio)
        val registrar = findViewById<Button>(R.id.buttonRegistrar)
        val consultar = findViewById<Button>(R.id.buttonConsultar)
        val editar = findViewById<Button>(R.id.buttonEditar)
        val eliminar = findViewById<Button>(R.id.buttonEliminar)

        registrar.setOnClickListener{
            val adminBD = AdminSQL(this, "MiTienda", null, 1) //crear constante en la que se reciben unos elementos, se hgereda la clase, para enviarle desde este activity los 4 datos
            val bd = adminBD.writableDatabase //objeto
            val registro = ContentValues() //objeto
            registro.put("codigo", codigo.text.toString().toInt())
            registro.put("nombre", nombre.text.toString())
            registro.put("precio", precio.text.toString().toDouble())

            bd.insert("producto", null, registro)
            bd.close()
            codigo.setText("")
            nombre.setText("")
            precio.setText("")
            Toast.makeText(this,"¡Producto registrado!", Toast.LENGTH_LONG).show()
        }
        consultar.setOnClickListener{
            val adminBD = AdminSQL(this, "MiTienda", null, 1) //crear constante en la que se reciben unos elementos, se hgereda la clase, para enviarle desde este activity los 4 datos
            val bd = adminBD.writableDatabase //objeto
            val consulta = bd.rawQuery("select nombre, precio from producto where codigo = ${codigo.text.toString()}", null) //permite buscar. lanza un select en la base de datos
            if (consulta.moveToFirst()){
                nombre.setText(consulta.getString(0))
                precio.setText(consulta.getString(1))
            }else{
                Toast.makeText(this, "¡Producto no encontrado!", Toast.LENGTH_LONG).show()
                nombre.setText("")
                precio.setText("")
            }
            bd.close()
        }
        editar.setOnClickListener{
            val adminBD = AdminSQL(this, "MiTienda", null, 1) //crear constante en la que se reciben unos elementos, se hgereda la clase, para enviarle desde este activity los 4 datos
            val bd = adminBD.writableDatabase //objeto
            val registro = ContentValues()
            registro.put("nombre", nombre.text.toString())
            registro.put("precio", precio.text.toString())
            val editar = bd.update("producto", registro, "codigo=${codigo.text.toString()}", null)
            bd.close()
            if (editar==1){
                Toast.makeText(this, "¡Producto Actualizado!", Toast.LENGTH_LONG).show()
                nombre.setText("")
                precio.setText("")
            }else{
                Toast.makeText(this, "¡El producto ingresado no existe!", Toast.LENGTH_LONG).show()
                nombre.setText("")
                precio.setText("")
            }
        }
        eliminar.setOnClickListener{
            val adminBD = AdminSQL(this, "MiTienda", null, 1) //crear constante en la que se reciben unos elementos, se hgereda la clase, para enviarle desde este activity los 4 datos
            val bd = adminBD.writableDatabase //objeto
            val eliminar = bd.delete("producto", "codigo=${codigo.text.toString()}", null)
            bd.close()
            codigo.setText("")
            nombre.setText("")
            precio.setText("")
            if (eliminar==1){
                Toast.makeText(this, "¡Producto Eliminado!", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this, "¡Producto no encontrado!", Toast.LENGTH_LONG).show()
            }
        }
    }
}